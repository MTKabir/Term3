﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;
using SomerenDAL;

namespace SomerenLogic
{
    public class SalesService
    {
        SalesDao salesDao;

        public SalesService()
        {
            salesDao = new SalesDao();
        }
        public void InsertSale(Student student, Drink drink)
        {
            salesDao.WriteRecord(student, drink);
        }
    }
}
