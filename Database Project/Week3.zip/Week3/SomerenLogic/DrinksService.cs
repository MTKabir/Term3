﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenDAL;
using SomerenModel;

namespace SomerenLogic
{
    public class DrinksService
    {
        DrinksDao drinksDao;
        public DrinksService()
        {
            drinksDao = new DrinksDao();
        }

        public List<Drink> GetAllDrinks()
        {
            return drinksDao.GetAllDrinks();
        }

    }
}
