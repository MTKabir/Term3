﻿using SomerenDAL;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenLogic
{
    public class ActivitiesService
    {
        ActivitiesDao activitydb;

        public ActivitiesService()
        {
            activitydb = new ActivitiesDao();
        }

        public List<Activities> GetActivities()
        {
            List<Activities> activities = activitydb.GetAllActivities();
            return activities;
        }
    }
}
