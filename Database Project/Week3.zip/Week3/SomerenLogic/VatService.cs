﻿using SomerenDAL;
using SomerenModel;
using System.Collections.Generic;


namespace SomerenLogic
{
    public class VatService
    {
        VatDAO vatDAO;

        public VatService()
        {
            vatDAO= new VatDAO();
        }
        public List<Vat> GetVats()
        {
            List<Vat> vats = vatDAO.GetAllVats();
            return vats;
        }
    }
}
