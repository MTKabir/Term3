﻿using SomerenModel;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace SomerenDAL
{
    public class VatDAO:BaseDao
    {
        public List<Vat> GetAllVats()
        {
            string query = "SELECT year,quarter,quarterStartingDate,quarterEndDate,lowVat,highVat FROM VatCalculator";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }
        private List<Vat> ReadTables(DataTable dataTable)
        {
            List<Vat> vats = new List<Vat>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Vat vat = new Vat()
                {
                    Year = (int)dr["year"],
                    Quarter = (string)dr["quarter"],
                    QuarterStartDate = (string)dr["quarterStartingDate"],
                    QuarterEndDate = (string)dr["quarterEndDate"],
                    LowVat= (int)dr["lowVat"],
                    HighVat= (int)dr["highVat"],  
                };
                vats.Add(vat);
            }
            return vats;
        }
    }
}
