﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;

namespace SomerenDAL
{
    public class SalesDao:BaseDao
    {
        public void WriteRecord(Student student, Drink drink)
        {
            string query = $"INSERT INTO Sales (student_number, drink_code) VALUES ({student.Number}, {drink.Id}); "; 
            SqlParameter[] sp = new SqlParameter[0];
            ExecuteEditQuery(query, sp);
        }
    }
}
