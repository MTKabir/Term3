﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Vat
    {
        public int Year { get; set; }
        public string Quarter { get; set; }
        public string QuarterStartDate { get; set; }
        public string QuarterEndDate { get; set; }
        public int LowVat { get; set; }
        public int HighVat { get; set; }
        public int TotalVat { get { return(LowVat + HighVat); } }
        public override string ToString()
        {
            return $"{Year} ({Quarter})";
        }
    }
}
