﻿using SomerenLogic;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomerenUI
{
    public partial class DrinkForm : Form
    {
        DrinksService drinksService = new DrinksService();
        public DrinkForm()
        {
            InitializeComponent();
            DisplayDrinks();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void DisplayDrinks()
        {
            lvDrinks.Items.Clear();
            List<Drink> drinks = drinksService.GetAllDrinks();
            foreach (Drink drink in drinks)
            {
                ListViewItem lv = new ListViewItem(drink.Name);
                lv.SubItems.Add(drink.Price.ToString());
                lv.SubItems.Add(drink.Stock.ToString());
                lv.SubItems.Add(drink.Type);
                lvDrinks.Items.Add(lv);
            }
            
        }
    }

}
