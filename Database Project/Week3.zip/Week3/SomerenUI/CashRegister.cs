﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SomerenModel;
using SomerenLogic;


namespace SomerenUI
{
    public partial class formCashReg : Form
    {
        public formCashReg()
        {
            InitializeComponent();
            DisplayStudents();
            DisplayDrinks();
        }
        
        StudentService studentService = new StudentService();
        DrinksService drinksService = new DrinksService();
        SalesService salesService = new SalesService();
        Student student = new Student();
        Drink drink;
        List<Drink> drinks = new List<Drink>();
        decimal totalPrice = 0;


        private void DisplayStudents()
        {
            List<Student> students = studentService.GetStudents();
            foreach (Student student in students)
            {
                cmbStudent.Items.Add(student);
            }
        }

        private void DisplayDrinks()
        {
            try
            {
                lvDrinks.Items.Clear();
                List<Drink> drinks = drinksService.GetAllDrinks();
                foreach (Drink drink in drinks)
                {
                    ListViewItem lv = new ListViewItem(drink.Id);
                    lv.SubItems.Add(drink.Name);
                    lv.SubItems.Add(drink.Price.ToString());
                    lv.SubItems.Add(drink.Stock.ToString());
                    lv.SubItems.Add(drink.Type);
                    lvDrinks.Items.Add(lv);
                }
                cmbStudent.SelectedIndex = 0;

            }
            catch ( Exception e)
            {
                MessageBox.Show("error:" + e.Message);
            }

        }

        private void cmbStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            student = (Student)cmbStudent.SelectedItem;
        }

        private void lvDrinks_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (lvDrinks.SelectedItems.Count == 0)
                {
                    return;

                }

                foreach (var item in lvDrinks.SelectedItems)
                {
                    drink = new Drink();
                    ListViewItem lv = lvDrinks.SelectedItems[0];
                    drink.Id = lv.Text;
                    drink.Name = lv.SubItems[1].Text;
                    drink.Price = decimal.Parse(lv.SubItems[2].Text);
                    drink.Stock = int.Parse(lv.SubItems[3].Text);
                    drink.Type = lv.SubItems[4].Text;
                    drinks.Add(drink);
                    totalPrice += drink.Price;
                }


                ShowTotalPrice(drink);

                btnCheckOut.Enabled = true;
            }
            catch (Exception exp)
            {
                MessageBox.Show("error:" + exp.Message);
            }
        }

        private void ShowTotalPrice(Drink drink)
        {
            tbTotal.Text = $"€ {totalPrice}";
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            try
            {
                int i = 0;
                foreach (var item in drinks)
                {
                    salesService.InsertSale(student, drinks[i]);
                    i++;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("error:" + exp.Message);

            }
            tbTotal.Text = "";
            cmbStudent.SelectedIndex = 0;
            btnCheckOut.Enabled = false;
        }
    }
}
