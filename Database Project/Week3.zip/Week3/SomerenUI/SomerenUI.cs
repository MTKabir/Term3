﻿using SomerenLogic;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SomerenUI
{
    public partial class SomerenUI : Form
    {
        public SomerenUI()
        {
            InitializeComponent();
        }

        private void SomerenUI_Load(object sender, EventArgs e)
        {
            showPanel("Dashboard");
        }

        private void showPanel(string panelName)
        {
            if (panelName == "Dashboard")
            {
                // hide all other panels
                pnlStudents.Hide();
                pnlActivities.Hide();
                pnlTeachers.Hide();
                pnlRooms.Hide();
                // show dashboard
                pnlDashboard.Show();
                imgDashboard.Show();
            }
            else if (panelName == "Students")
            {
                // By Mirko Cuccurullo ID: 691362

                // hide all other panels

                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlActivities.Hide();
                pnlTeachers.Hide();
                pnlRooms.Hide();

                // show students
                pnlStudents.Show();

                try
                {
                    // filling the students listview
                    StudentService studService = new StudentService(); 
                    List<Student> studentList = studService.GetStudents(); 

                    // clearing the listview 
                    listViewStudents.Items.Clear();

                    foreach (Student s in studentList)
                    {
                        ListViewItem li = new ListViewItem(s.Number.ToString());
                        li.SubItems.Add(s.Name);
                        li.SubItems.Add(s.LastName);
                        listViewStudents.Items.Add(li);
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the students: " + e.Message);
                }
            }
            else if (panelName == "Activities")
            {
                // hide all other panels
                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlStudents.Hide();
                pnlTeachers.Hide();
                pnlRooms.Hide();

                //showing activities
                pnlActivities.Show();

                try
                {
                    ActivitiesService activitiesService = new ActivitiesService(); 
                    List<Activities> activityList = activitiesService.GetActivities(); 

                    // clear the listview before filling it again
                     listViewActivities.Items.Clear();

                    foreach (Activities a in activityList)
                    {
                        ListViewItem li = new ListViewItem(a.Name);
                        li.SubItems.Add(a.Type);
                        li.SubItems.Add(a.startDate.ToString());
                        li.SubItems.Add(a.endDate.ToString());
                        listViewActivities.Items.Add(li);
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the activities: " + e.Message);
                }
            }
            else if (panelName == "Teachers")
            {
                // hide all other panels
                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlStudents.Hide();
                pnlActivities.Hide();
                pnlRooms.Hide();

                // show teachers
                pnlTeachers.Show();

                try
                {
                    // fill the students listview within the students panel with a list of students
                    TeacherService teachService = new TeacherService(); 
                    List<Teacher> teacherList = teachService.GetTeachers(); 

                    // clear the listview before filling it again
                    listViewTeachers.Items.Clear();

                    foreach (Teacher teacher in teacherList)
                    {
                        ListViewItem li = new ListViewItem(teacher.Number);
                        li.SubItems.Add(teacher.Name);
                        li.SubItems.Add(teacher.Emailaddress);
                        listViewTeachers.Items.Add(li);
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the teacher: " + e.Message);
                }
            }
            else
            {
                // hide all other panels
                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlTeachers.Hide();
                pnlStudents.Hide();
                pnlActivities.Hide();

                // show rooms
                pnlRooms.Show();

                try
                {
                    // fill the rooms listview within the rooms panel with a list of rooms
                    RoomsService roomService = new RoomsService(); 
                    List<Room> roomsList = roomService.GetRooms(); 

                    // clear the listview before filling it again
                    listViewRooms.Items.Clear();

                    foreach (Room r in roomsList)
                    {
                        ListViewItem li = new ListViewItem(r.Number.ToString());
                        li.SubItems.Add(r.Capacity.ToString());
                        li.SubItems.Add(r.Type);
                        listViewRooms.Items.Add(li);
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the Room: " + e.Message);
                }
            }
        }

        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dashboardToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            showPanel("Dashboard");
        }

        private void imgDashboard_Click(object sender, EventArgs e)
        {
            MessageBox.Show("What happens in Someren, stays in Someren!");
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Students");
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Activities");
        }

        private void lecturersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Teachers");
        }
        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Rooms");
        }

        private void cashRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formCashReg register = new formCashReg();
            register.ShowDialog();
        }

        private void drinksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DrinkForm form = new DrinkForm();
            form.ShowDialog();
        }

        private void vatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VatForm vatForm = new VatForm();
            vatForm.ShowDialog();
        }
    }
}
