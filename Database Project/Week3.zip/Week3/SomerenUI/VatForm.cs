﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SomerenLogic;
using SomerenModel;

namespace SomerenUI
{
    public partial class VatForm : Form
    {
        Vat vat;
        VatService vatService;

        public VatForm()
        {
            InitializeComponent();
            vat = new Vat();
            vatService = new VatService();
            LoadVat();
        }
        private void LoadVat()
        {
            try
            {
                List<Vat> vats = vatService.GetVats();
                foreach (Vat vatitems in vats)
                {
                    cmbYear.Items.Add(vatitems);
                    
                    
                    //cmbQuarter.Items.Add(vatitems.Quarter);
                    //cmbQuarter.Items.Add(vatitems.QuarterStartDate);
                    //cmbQuarter.Items.Add(vatitems.QuarterEndDate);

                    ListViewItem item = new ListViewItem(vatitems.LowVat.ToString());
                    item.SubItems.Add(vatitems.HighVat.ToString());
                    item.SubItems.Add(vatitems.TotalVat.ToString());
                    lvVat.Items.Add(item);
                }
                //cmbYear.SelectedIndex = 0;
                //cmbQuarter.SelectedIndex = 0;
            }
            catch (Exception e)
            {
                MessageBox.Show("error:" + e.Message);
            }

        }

        private void cmbYear_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try
            {
                vat = (Vat)cmbYear.SelectedItem;
                lblStartDate.Text = $"{vat.QuarterStartDate}";
                lblEndDate.Text = vat.QuarterEndDate;
            }
            catch (Exception ei)
            {
                MessageBox.Show("error:" + ei.Message);
            }
        }
    }
}
