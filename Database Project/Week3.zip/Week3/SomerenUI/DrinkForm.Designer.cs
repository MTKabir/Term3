﻿namespace SomerenUI
{
    partial class DrinkForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvDrinks = new System.Windows.Forms.ListView();
            this.DrinkName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DrinkPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DrinkStock = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DrinkType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // lvDrinks
            // 
            this.lvDrinks.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.DrinkName,
            this.DrinkPrice,
            this.DrinkStock,
            this.DrinkType});
            this.lvDrinks.HideSelection = false;
            this.lvDrinks.Location = new System.Drawing.Point(127, 124);
            this.lvDrinks.Name = "lvDrinks";
            this.lvDrinks.Size = new System.Drawing.Size(987, 308);
            this.lvDrinks.TabIndex = 0;
            this.lvDrinks.UseCompatibleStateImageBehavior = false;
            this.lvDrinks.View = System.Windows.Forms.View.Details;
            this.lvDrinks.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // DrinkName
            // 
            this.DrinkName.Text = "Name";
            this.DrinkName.Width = 100;
            // 
            // DrinkPrice
            // 
            this.DrinkPrice.Text = "Price";
            // 
            // DrinkStock
            // 
            this.DrinkStock.Text = "Stock";
            // 
            // DrinkType
            // 
            this.DrinkType.Text = "Type";
            // 
            // DrinkForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1210, 583);
            this.Controls.Add(this.lvDrinks);
            this.Name = "DrinkForm";
            this.Text = "DrinkForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvDrinks;
        private System.Windows.Forms.ColumnHeader DrinkName;
        private System.Windows.Forms.ColumnHeader DrinkPrice;
        private System.Windows.Forms.ColumnHeader DrinkStock;
        private System.Windows.Forms.ColumnHeader DrinkType;
    }
}